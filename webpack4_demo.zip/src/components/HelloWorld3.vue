<template>
  <div class="hello">
    <h1>HelloWorld3</h1>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld3',
  created () {
    console.log('HelloWorld3 init')
  }
}
</script>
