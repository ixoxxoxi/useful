<template>
  <div class="hello">
    <h1>HelloWorld2</h1>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld2',
  created () {
    console.log('HelloWorld2 init')
  }
}
</script>
