<template>
  <div class="hello">
    <h1>HelloWorld1</h1>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld1',
  created () {
    console.log('HelloWorld1 init')
  }
}
</script>
