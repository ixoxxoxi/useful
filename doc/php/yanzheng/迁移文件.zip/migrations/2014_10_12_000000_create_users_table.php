<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('phone')->nullable()->comment('手机号');
            $table->string('avatar')->nullable()->comment('用户头像');
            $table->tinyInteger('is_locked')->default(0)->comment('用户禁用状态: 0正常 1禁用');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('openid')->nullable()->comment('微信公众平台openid');
            $table->string('unionid')->nullable()->comment('微信开放平台unionid');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
