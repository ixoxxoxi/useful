<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Good extends Model
{
    use HasFactory;
    // 可批量赋值字段
    protected $fillable = [
        'user_id',
        'category_id',
        'title',
        'description',
        'price',
        'stock',
        'cover',
        'pics',
        'is_on',
        'is_recommend',
        'details',
    ];

    // 商品所属的分类
    public function category()
    {
        return $this->belongsTo(Category::class,'category_id','id');
    }
    // 商品所属的用户
    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

    // 商品关联的评论
    public function comments()
    {
        return $this->hasMany(Comment::class,'goods_id','id');
    }

    // 商品关联的收藏
    public function collects()
    {
        return $this->hasMany(Collect::class,'goods_id','id');
    }

}
