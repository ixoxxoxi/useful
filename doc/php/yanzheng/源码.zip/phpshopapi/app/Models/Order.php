<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'order_no',
        'amount',
        'status',
        'address_id',
        'pay_type',
        'trade_no',
    ];

    /**
     * 关联用户
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

    /**
     * 关联地址
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function address()
    {
        return $this->belongsTo(Address::class,'address_id','id');
    }

    // 订单详情
    public function orderDetails()
    {
        return $this->hasOne(OrderDetails::class,'order_id','id');
    }

    // 订单关联的商品

    public function goods()
    {
        return $this->hasManyThrough(
            Good::class,  // 最终关联的模型
            OrderDetails::class, // 中间表模型
            'order_id', // 中间模型和本模型的关联外键
                'id', // 最终关联模型的外键
            'id', // 本模型的ID
            'goods_id' // 中间表和最终模型的关联的一个外键
        );
    }

}
