<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collect extends Model
{
    use HasFactory;

    public function goods()
    {
        return $this->belongsTo(Good::class,'goods_id','id');
    }
}
