import { Route, Routes, useNavigate, useLocation } from 'react-router-dom';
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getInfo } from "@/store/asyncAction";
import Layout from '../components/Layout';
import Login from '../pages/login';
import { routerData } from './config';
import { generateRoutes } from '@/store/permission.js'
import { handleRouterData } from './config';



export default () => {

    const dispatch = useDispatch();
    const { token, roles, accessRoutes } = useSelector(state => state.user);
    const navigator = useNavigate();
    const { pathname } = useLocation();

    // 监听token变化
    useEffect(() => {
        if (token) {
            dispatch(getInfo())
        } else {
            navigator("/login", { replace: true })
        }
    }, [token])

    useEffect(() => {
        if (roles && roles.length > 0) {
            dispatch(generateRoutes(routerData, roles))
        }
    }, [roles])

    useEffect(() => {
        if (accessRoutes && accessRoutes.length > 0 && pathname === '/login') {
            navigator("/dashboard", { replace: true })
        }
    }, [accessRoutes])

    useEffect(() => {
        if (token && pathname === "/login") {
            navigator("/", { replace: true })
        }
        if (token && pathname === "/") {
            navigator("/dashboard", { replace: true })
        }
        if (!token && pathname !== "/login") {
            navigator("/login", { replace: true })
        }
    }, [pathname])

    let data = handleRouterData(accessRoutes);

    return (
        <Routes>
            <Route path="/*" element={
                <Layout>
                    <Routes>
                        {data.map(i => (<Route key={i.key} path={i.path} element={i.element} />))}
                    </Routes>
                </Layout>
            } />
            {/* <Route path='/' element={<Navigate to='/dashboard' />} /> */}
            <Route path='/login' element={<Login />} />
        </Routes>
    )
}