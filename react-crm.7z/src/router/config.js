import Dashboard from "../pages/dashboard";
import GoodsList from '../pages/goods/goodsList';
import GoodsForm from '../pages/goods/goodsForm';
import User from "../pages/user";
import Login from "../pages/login";
import { FormattedMessage } from "react-intl";

import {
    UserOutlined,
    ShoppingOutlined,
    UnorderedListOutlined,
    FileAddOutlined,
    EditOutlined,
    DashboardOutlined
} from '@ant-design/icons';
import { Navigate } from 'react-router-dom';

export const staticRoutes = [
    {
        path: '/login',
        key: '/login',
        element: <Login />
    }
]

export const routerData = [
    {
        path: '/dashboard',
        key: '/dashboard',
        label: <FormattedMessage id="menu.dashboard" />,
        icon: <DashboardOutlined />,
        element: <Dashboard />,
        meta: {
            roles: ['admin', 'editor']
        }
    },
    {
        path: '/goods',
        key: '/goods',
        label: <FormattedMessage id="menu.goods" />,
        icon: <ShoppingOutlined />,
        element: <Navigate to='/goods/list' />,
        meta: {
            roles: ['admin', 'editor']
        },
        children: [
            {
                path: '/goods/list',
                key: '/goods/list',
                label: <FormattedMessage id="menu.goods.list" />,
                icon: <UnorderedListOutlined />,
                element: <GoodsList />
            },
            {
                path: '/goods/add',
                key: '/goods/add',
                label: <FormattedMessage id="menu.goods.add" />,
                icon: <FileAddOutlined />,
                element: <GoodsForm />,
                hidden: true
            },
            {
                path: '/goods/edit/:id',
                key: '/goods/edit',
                label: <FormattedMessage id="menu.goods.edit" />,
                icon: <EditOutlined />,
                element: <GoodsForm />,
                hidden: true
            },
        ]
    },
    {
        path: '/user',
        key: '/user',
        label: <FormattedMessage id="menu.user" />,
        icon: <UserOutlined />,
        element: <User />,
        meta: {
            roles: ['admin', 'editor']
        }
    }
]

export const handleRouterData = (data) => {
    let arr = [];
    data.forEach(i => {
        if (i.children) {
            i.children.forEach(j => {
                arr.push(j)
            })
        }
        arr.push(i)
    });
    return arr;
}

export const calMenuItems = data => {
    let arr = data.map(i => {
        if (!i.hidden) {
            if (i.children) {
                return {
                    key: i.key,
                    icon: i.icon,
                    children: calMenuItems(i.children),
                    label: i.label
                }
            } else {
                return {
                    key: i.key,
                    icon: i.icon,
                    label: i.label
                }
            }
        }

    })
    return arr;
}


export const calOpenkey = (path) => {
    let key = '';
    routerData.forEach(i => {
        if (i.children && i.children.length > 0) {
            i.children.forEach(j => {
                if (j.path === path) {
                    key = i.key;
                }
            })
        }
    })
    return key;
}

export const breadcrumbItem = path => {
    let arr = [];
    arr.push({ ...routerData[0] });
    if (path !== '/dashboard') {
        routerData.forEach(i => {
            if (i.children) {
                i.children.forEach(j => {
                    if (j.path === path) {
                        arr.push({ ...i }, { ...j })
                    }
                })
            } else {
                if (i.path === path) {
                    arr.push({ ...i })
                }
            }
        });
    }
    return arr;
}