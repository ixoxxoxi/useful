import './layout.css';
import { Layout, Menu, theme, Col, Row, Dropdown, ConfigProvider } from 'antd';
import {
    MenuFoldOutlined,
    MenuUnfoldOutlined,
    FullscreenOutlined,
    FullscreenExitOutlined,
    FontSizeOutlined,
    FontColorsOutlined
} from '@ant-design/icons';
import Setting_draweer from '../setting_draweer';
import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { calMenuItems, calOpenkey } from '@/router/config';
import screenfull from 'screenfull';
import Breadcrumbs from '../breadcrumbs';
import { switchSize, switchLang } from '@/store/action.js'
import { useNavigate, Outlet, useLocation } from "react-router-dom";
import en_GB from 'antd/locale/en_US';
import zh_CN from 'antd/locale/zh_CN';
import C_zh_CN from '@/Locale/zh_CN';
import C_en_GB from '@/Locale/en_GB';
import { IntlProvider } from 'react-intl';

const { Header, Sider, Content } = Layout;


export default (props) => {
    // 菜单栏收缩
    const [collapsed, setCollapsed] = useState(false);

    const { accessRoutes } = useSelector(state => state.user);
    const MenuItems = calMenuItems(accessRoutes);
    const {
        token: { colorBgContainer },
    } = theme.useToken();

    const { pathname } = useLocation();
    const navigate = useNavigate();
    const openkey = calOpenkey(pathname);

    // 全屏
    const [full, setFull] = useState(false);
    useEffect(() => {
        screenfull.onchange(() => {
            setFull(screenfull.isFullscreen)
        })
    }, [])
    const toggleFull = () => {
        if (screenfull.isEnabled) {
            screenfull.toggle()
        }
    }
    // 组件尺寸相关
    const { size } = useSelector(state => state.app);
    const dispatch = useDispatch();
    const sizeArr = ['large', 'middle', 'small'];

    const sizeItems = sizeArr.map((item, index) => {
        return {
            key: index,
            label: (<div className={`size ${size === item ? 'on' : ''}`} onClick={() => changeSize(item)}>{item}</div>)
        }
    });
    const changeSize = size => {
        // dispatch({
        //     type: 'APP_SIZE',
        //     payload: size
        // })
        dispatch(switchSize(size))
    }
    // 语言国际化相关
    const { lang } = useSelector(state => state.app);
    const langArr = [
        { value: 'zh_CN', label: '简体中文' },
        { value: 'en_GB', label: 'English' }
    ];
    const langs = {
        zh_CN,
        en_GB
    };
    const content_lang = {
        zh_CN: C_zh_CN,
        en_GB: C_en_GB
    }

    const langItems = langArr.map((item, index) => {
        return {
            key: item.value,
            label: (<div className={`lang ${lang === item.value ? 'on' : ''}`} onClick={() => changeLang(item.value)}>{item.label}</div>)
        }
    });
    const changeLang = lang => {
        dispatch(switchLang(lang))
    };
    // 主题色
    const { color } = useSelector(state => state.app);
    // 自动开关侧边栏
    const resizeHandler = ev => {
        setCollapsed(ev.srcElement.innerWidth <= 800)
    }
    useEffect(() => {
        window.addEventListener("resize", resizeHandler);
        return () => {
            window.removeEventListener("resize", resizeHandler)
        }
    })


    return (
        <ConfigProvider componentSize={size} locale={langs[lang]} theme={{ token: { colorPrimary: color } }}>
            <IntlProvider messages={content_lang[lang]} locale={navigator.language}>
                <Layout style={{ position: 'fixed', top: 0, left: 0, bottom: 0 }}>
                    <Sider trigger={null} collapsible collapsed={collapsed}>
                        {
                            collapsed
                                ? (<div className="logo small" >C</div>)
                                : (<div className="logo" >CRM管理系统</div>)
                        }

                        <Menu
                            theme="dark"
                            mode="inline"
                            defaultSelectedKeys={[pathname]}
                            defaultOpenKeys={[openkey]}
                            items={MenuItems}
                            onClick={(v) => { navigate(v.key) }}
                        />
                    </Sider>
                    <Layout className="site-layout" style={{ minWidth: '800px' }}>
                        <Header
                            style={{
                                padding: 0,
                                background: colorBgContainer,
                            }}
                        >
                            <Row>
                                <Col span={1.5}>
                                    {React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
                                        className: 'trigger',
                                        onClick: () => setCollapsed(!collapsed),
                                    })}
                                </Col>
                                <Col span={12}>
                                    <Breadcrumbs />
                                </Col>
                                <Col span={3} offset={5}>
                                    <div className='header_icon'>
                                        <div onClick={toggleFull}>
                                            {
                                                full ? <FullscreenExitOutlined /> : <FullscreenOutlined />
                                            }
                                        </div>
                                        <Dropdown
                                            menu={{
                                                items: sizeItems
                                            }}
                                            placement="bottom"
                                            arrow
                                        >
                                            <FontSizeOutlined />
                                        </Dropdown>
                                        <Dropdown
                                            menu={{
                                                items: langItems
                                            }}
                                            placement="bottom"
                                            arrow
                                        >
                                            <FontColorsOutlined />
                                        </Dropdown>
                                    </div>
                                </Col>
                            </Row>
                        </Header>
                        <Content
                            style={{
                                margin: '24px 16px',
                                padding: 24,
                                minHeight: 280,
                                overflowY: 'scroll',
                                scrollbarWidth: 'none',
                                background: colorBgContainer,
                            }}
                        >
                            {/* 两种写法效果相同 */}
                            {props.children}
                            <Setting_draweer />
                            {/* <Outlet /> */}
                        </Content>
                    </Layout>
                </Layout >
            </IntlProvider>
        </ConfigProvider>
    )
}
