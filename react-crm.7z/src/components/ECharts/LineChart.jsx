import * as echarts from 'echarts/core';
import { GridComponent, TooltipComponent, LegendComponent } from 'echarts/components';
import { LineChart } from 'echarts/charts';
import { UniversalTransition } from 'echarts/features';
import { CanvasRenderer } from 'echarts/renderers';

import { useEffect } from 'react';


export default () => {
    echarts.use([GridComponent, TooltipComponent, LegendComponent, LineChart, CanvasRenderer, UniversalTransition]);

    var option;

    option = {
        xAxis: {
            type: 'category',
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            boundaryGap: false,
            axisTick: {
                show: false
            }
        },
        grid: {
            left: 10,
            right: 10,
            bottom: 20,
            top: 30,
            containLabel: true
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            },
            padding: [5, 10]
        },

        yAxis: {
            type: 'value',
            axisTick: {
                show: false
            }
        },
        legend: {
            data: ['expected', 'actual']
        },
        series: [
            {
                name: 'expected',
                itemStyle: {
                    color: '#FF005A',
                    lineStyle: {
                        color: '#FF005A',
                        width: 2
                    }
                },
                smooth: true,
                type: 'line',
                data: [100, 120, 161, 134, 105, 160, 165],
                animationDuration: 2800,
                animationEasing: 'cubicInOut'
            },
            {
                name: 'actual',
                smooth: true,
                type: 'line',
                itemStyle: {
                    color: '#3888fa',
                    lineStyle: {
                        color: '#3888fa',
                        width: 2
                    },
                    areaStyle: {
                        color: '#f3f8ff'
                    }
                },
                data: [120, 82, 91, 154, 162, 140, 145],
                animationDuration: 2800,
                animationEasing: 'quadraticOut'
            }
        ]
    };

    useEffect(() => {
        var chartDom = document.getElementById('linechart');
        var myChart = echarts.init(chartDom);
        myChart.setOption(option);
    }, [])


    return (
        <div id="linechart" style={{ width: "100%", height: "300px" }}></div>
    )
}