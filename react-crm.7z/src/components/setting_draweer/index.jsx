import './drawer_content.css';

import { useState } from 'react';
import { Drawer } from 'antd';
import { useIntl } from 'react-intl';
import { TwitterPicker } from 'react-color';
import { useDispatch, useSelector } from 'react-redux';
import { switchColor } from '@/store/action';

import {
    SettingOutlined
} from '@ant-design/icons';

export default () => {

    const [open, setOpen] = useState(false);
    const showDrawer = () => {
        setOpen(true);
    };
    const onClose = () => {
        setOpen(false);
    };
    const intl = useIntl();
    const dispatch = useDispatch();
    const { color } = useSelector(state => state.app);

    const changeColor = (e) => {
        // console.log(e);
        dispatch(switchColor(e.hex))
    }

    return (

        <div className="setting" >
            {/* <div className="btn" onClick={showDrawer} style={{ right: open ? '378px' : 0 }}> */}
            <div className="btn" onClick={showDrawer} style={{ backgroundColor: color }}>
                <SettingOutlined />
            </div>
            <Drawer
                title={intl.formatMessage({ id: "setting.drawer.title" })}
                placement='right'
                key='right'
                closable
                onClose={onClose}
                open={open}
            >
                <TwitterPicker onChangeComplete={changeColor} color={color} />
            </Drawer>
        </div>
    )
}