import { Chart, Interval, Tooltip } from 'bizcharts';
import { useMemo } from "react"


export default function BarChart() {

    const data = useMemo(() => {
        // 使用useMemo，对后端数据进行处理，得到图表需要的数据格式
        const result = [
            { year: '1951 年', sales: 0 },
            { year: '1952 年', sales: 52 },
            { year: '1956 年', sales: 61 },
            { year: '1957 年', sales: 45 },
            { year: '1958 年', sales: 48 },
            { year: '1959 年', sales: 38 },
            { year: '1960 年', sales: 38 },
            { year: '1962 年', sales: 38 },
        ]
        return result;
    }, [])


    return <Chart height={300} autoFit data={data} >
        <Interval position="year*sales" />
        <Tooltip shared />
    </Chart>
}
