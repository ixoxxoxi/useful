import { useNavigate, useLocation } from 'react-router-dom';

import { breadcrumbItem } from '@/router/config';

import { Breadcrumb } from 'antd';


export default () => {
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const items = breadcrumbItem(pathname);

    const goto = (i, j) => {
        if (i.path && j !== items.length - 1) {
            navigate(i.path)
        }
    }
    const isSkip = (i, j) => {
        return i.path && j !== items.length - 1;
    }

    return (
        <Breadcrumb style={{ lineHeight: '64px' }}>
            {items.map((i, j) => (<Breadcrumb.Item key={i.key} onClick={() => goto(i, j)}>
                <span style={
                    {
                        cursor: isSkip(i, j) ? 'pointer' : 'default',
                        color: isSkip(i, j) ? '#333' : 'rgb(192, 188, 188)'
                    }
                }>{i.label}</span>
            </Breadcrumb.Item>))}
        </Breadcrumb>
    )
}