import { fetchLogin, fetchUserInfo, } from '@/api/user';
import { fetchCates } from '@/api/goods';

export function login(data) {
    return function (dispatch) {
        fetchLogin(data).then(res => {
            // console.log('login res', res);
            if (res.token) {
                localStorage.setItem('token', res.token)
                dispatch({ type: 'USER_LOGIN', payload: res.token })
            }
        })
    }
}

export function getInfo() {
    // 返回一个函数
    return function (dispatch) {
        fetchUserInfo().then((res) => {
            // console.log("用户信息：", res);
            if (res && res.roles) {
                dispatch({ type: "USER_INFO", payload: res })
            }
        })
    }
}

export function resetUser(color) {
    return { type: "USER_RESET", payload: null }
}

export function getCates() {
    return dispatch => {
        fetchCates().then(res => {
            // console.log(res);
            if (res.list) {
                dispatch({ type: "GOODS_CATES", payload: res.list })
            }
        })
    }
}