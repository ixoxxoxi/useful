import produce from "immer";

const initState = {
    token: localStorage.getItem("token") || null,
    avatar: "",
    introduction: "",
    name: "",
    roles: [],
    accessRoutes: []
}

export default (state = initState, { type, payload }) => {
    return produce(state, newState => {
        // CRUD
        switch (type) {
            case "USER_LOGIN":
                localStorage.setItem("token", payload)
                newState.token = payload;
                break;
            case "USER_INFO":
                const { avatar, introduction, name, roles } = payload;
                newState.avatar = avatar;
                newState.introduction = introduction;
                newState.name = name;
                newState.roles = roles;
                break;
            case "USER_PERMISSION":
                newState.accessRoutes = payload;
                break;
            case "USER_RESET":
                localStorage.removeItem("token");
                newState.avatar = "";
                newState.introduction = "";
                newState.name = "";
                newState.roles = [];
                newState.token = "";
                break;
            default:
                break;
        }
    })
}
