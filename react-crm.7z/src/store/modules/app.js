import produce from "immer";

const initState = {
    size: localStorage.getItem('react_crm_config_size') || 'middle',
    lang: localStorage.getItem('react_crm_config_lang') || navigator.language.replace(/-/g, '_'),
    color: localStorage.getItem('react_crm_config_color') || '#1890ff'
}

// function reducer(state = initState, action) {
function reducer(state = initState, { type, payload }) {
    return produce(state, (newState) => {
        switch (type) {
            case 'APP_SIZE':
                newState.size = payload;
                localStorage.setItem('react_crm_config_size', payload)
                break;
            case 'APP_LANG':
                newState.lang = payload;
                localStorage.setItem('react_crm_config_lang', payload)
                break;
            case 'APP_COLOR':
                newState.color = payload;
                localStorage.setItem('react_crm_config_color', payload)
                break;
            default:
        }
    })
}

export default reducer;