import produce from "immer";

const initState = {
    cates: []
};

export default (state = initState, { type, payload }) => {
    return produce(state, state => {
        switch (type) {
            case 'GOODS_CATES':
                state.cates = payload;
                break;
            default:
        }
    })
}