import { legacy_createStore as createStore, combineReducers, applyMiddleware, compose } from 'redux';
import logger from 'redux-logger';
import thunk from 'redux-thunk';

import app from './modules/app';
import user from './modules/user';
import goods from './modules/goods';

const reducer = combineReducers({
    app,
    user,
    goods
});

const store = createStore(reducer, compose(applyMiddleware(thunk), applyMiddleware(logger)));

// console.log(store);

export default store;