export function switchSize(size) {
    return { type: "APP_SIZE", payload: size }
}
export function switchLang(lang) {
    return { type: "APP_LANG", payload: lang }
}
export function switchColor(color) {
    return { type: "APP_COLOR", payload: color }
}
