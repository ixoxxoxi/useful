// import { useSelector, useDispatch } from 'react-redux';
import { DatePicker, Space, Button, Tooltip } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { useIntl } from 'react-intl';
// import user from '../../store/modules/user';
const onChange = (date, dateString) => {
    console.log(date, dateString);
};

function User() {

    // let { size } = useSelector(state => {
    //     // console.log(state);
    //     return state.app;
    // });
    // const dispatch = useDispatch();
    // const sizeAdd = () => {
    //     dispatch({
    //         type: 'APP_SIZE_ADD',
    //         payload: 2
    //     })
    // }
    const intl = useIntl();

    return (
        <div>
            <h1>{intl.formatMessage({ id: 'user.title' })}</h1>
            {/* <p>{size}</p>
            <button onClick={sizeAdd}>size++</button> */}
            <Space direction="vertical">
                <DatePicker onChange={onChange} />
                <DatePicker onChange={onChange} picker="week" />
                <DatePicker onChange={onChange} picker="month" />
                <DatePicker onChange={onChange} picker="quarter" />
                <DatePicker onChange={onChange} picker="year" />
            </Space>
            <Space direction="vertical">
                <Space wrap>
                    <Tooltip title="search">
                        <Button type="primary" shape="circle" icon={<SearchOutlined />} />
                    </Tooltip>
                    <Button type="primary" shape="circle">
                        A
                    </Button>
                    <Button type="primary" icon={<SearchOutlined />}>
                        Search
                    </Button>
                    <Tooltip title="search">
                        <Button shape="circle" icon={<SearchOutlined />} />
                    </Tooltip>
                    <Button icon={<SearchOutlined />}>Search</Button>
                </Space>
                <Space wrap>
                    <Tooltip title="search">
                        <Button shape="circle" icon={<SearchOutlined />} />
                    </Tooltip>
                    <Button icon={<SearchOutlined />}>Search</Button>
                    <Tooltip title="search">
                        <Button type="dashed" shape="circle" icon={<SearchOutlined />} />
                    </Tooltip>
                    <Button type="dashed" icon={<SearchOutlined />}>
                        Search
                    </Button>
                    <Button icon={<SearchOutlined />} href="https://www.google.com" />
                </Space>
            </Space>
        </div>
    )
}

export default User;