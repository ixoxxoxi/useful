import BarChartDemo01 from "@/components/Bizcharts/BarChartDemo01";
import LineChartsDemo from "@/components/Bizcharts/LineChart";
import PieCharts from "@/components/Bizcharts/PieCharts";

import E_LineChart from "@/components/ECharts/LineChart";
import E_RaddarChart from "../../components/ECharts/RaddarChart";
import E_PieChart from "../../components/ECharts/PieChart";
import E_BarChart from "../../components/ECharts/BarChart";

import { Row, Col } from "antd";


function Dashboard() {


    return (
        <>
            <Row>
                <Col span={24}>
                    <E_LineChart />
                </Col>
            </Row>
            <Row>
                <Col span={8} >
                    <E_RaddarChart />
                </Col>
                <Col span={8} >
                    <E_PieChart />
                </Col>
                <Col span={8} >
                    <E_BarChart />
                </Col>
            </Row>
        </>
    )
}

export default Dashboard;