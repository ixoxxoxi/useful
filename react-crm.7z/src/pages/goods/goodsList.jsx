import { Button, Row, Col, Input, Table } from "antd"
import { useNavigate } from "react-router-dom"
import CateSelect from "./components/CateSelect"
import { PlusOutlined, ReloadOutlined, ColumnHeightOutlined, SettingOutlined } from "@ant-design/icons"
import { useIntl } from "react-intl";
import "./style.scss"
import { useEffect, useState } from "react";
import { fetchGoodList } from "@/api/goods";
import { useSelector } from "react-redux";
import moment from "moment/moment";



export default (props) => {

    const { cates } = useSelector(state => state.goods);
    const calCategory = cate => {
        return cates.filter(i => i.cate === cate)[0].cate_zh
    };
    const columns = [
        {
            title: '商品',
            align: 'center',
            dataIndex: 'name',
            render: (text, row, index) => {
                return (
                    <div className="goods">
                        <img src={`http://47.94.210.129:9999${row.img}`} alt="" />
                        <div>{text}</div>
                    </div>
                )
            },
        },
        {
            title: '价格',
            dataIndex: 'price',
            align: 'center',
            render: text => (
                <div>{`￥${Number(text).toFixed(2)}`}</div>
            )
        },
        {
            title: '品类',
            dataIndex: 'cate',
            align: 'center',
            render: cate => {
                return (
                    <div>{calCategory(cate)}</div>
                )
            }
        },
        {
            title: '是否热销',
            dataIndex: 'hot',
            align: 'center',
            render: text => (
                <div>{text ? '是' : '否'}</div>
            )
        },
        {
            title: '状态',
            dataIndex: 'store_status',
            align: 'center',
            render: text => (
                <div>{text ? '已上架' : '待上架'}</div>
            )
        },
        {
            title: '发布时间',
            dataIndex: 'create_time',
            align: 'center',
            render: time => {
                const m = moment(time)
                return (
                    <>
                        <div>{m.format('YYYY年MM月DD日')}</div>
                        <div>{m.format('HH:mm:ss')}</div>
                    </>
                )
            }
        },
        {
            title: '操作',
            align: 'center',
            render: (_, row) => (
                <>
                    <Button
                        type='primary'
                        size='small'
                        onClick={() => navigate('/goods/edit/' + row._id)}
                    >
                        编辑
                    </Button>
                    <Button danger size='small' style={{ marginLeft: '10px' }}>删除</Button>
                </>
            )
        }
    ]


    const [params, setParams] = useState({
        page: 1,
        size: 5,
        cate: '',
        name: ''
    });
    const [total, setTotal] = useState(0);
    const [list, setList] = useState([]);
    useEffect(() => {
        fetchGoodList(params).then(res => {
            // console.log(res);
            if (res.list) {
                setList(res.list);
                setTotal(res.total);
            }
        })
    }, [params])


    const intl = useIntl();
    const navigate = useNavigate();


    return (
        <div className="goods-list">
            <div className="filter">
                <Row justify="center" align="middle">
                    <Col span={3}>
                        <span>商品名称：</span>
                    </Col>
                    <Col span={4}>
                        <Input />
                    </Col>
                    <Col span={3}>
                        <span>商品分类：</span>
                    </Col>
                    <Col span={4}>
                        <CateSelect hasAll={true} value={params.cate} onChange={cate => setParams({ ...params, cate, page: 1 })} />
                    </Col>
                </Row>
            </div>
            <div className="table">
                <Table
                    rowSelection={{
                        type: "checkbox",
                        onChange: (keys, rows) => {
                            console.log(keys, rows);
                        }
                    }}
                    columns={columns}
                    dataSource={list}
                    rowKey="_id"
                    title={() => (
                        <Row>
                            <Col span={4}>商品列表</Col>
                            <Col span={6} offset={14} style={{ textAlign: "right" }}>
                                <Button
                                    type="primary"
                                    icon={<PlusOutlined />}
                                    onClick={() => navigate("/goods/add")}
                                >新增</Button>
                                <div className="table-title">
                                    <ReloadOutlined />
                                    <ColumnHeightOutlined />
                                    <SettingOutlined />
                                </div>
                            </Col>
                        </Row>
                    )}
                    pagination={{
                        total: total,
                        current: params.page,
                        pageSize: params.size,
                        showSizeChanger: true,
                        showTotal: (t, r) => (<div>{`第${r[0]}-${r[1]}条  共${t}条`}</div>),
                        onChange: (page, size) => setParams({ ...params, page, size })
                    }}
                />
            </div>

        </div>
    )
}
