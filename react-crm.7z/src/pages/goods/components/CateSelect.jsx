
import { Select } from 'antd';
import { useSelector, useDispatch } from 'react-redux';
import { getCates } from '@/store/asyncAction';
import { useLayoutEffect } from 'react';

const { Option } = Select;

export default ({ value, onChange, hasAll }) => {

    const dispatch = useDispatch();
    useLayoutEffect(() => {
        dispatch(getCates())
    }, [])
    const { cates } = useSelector(state => state.goods);

    return (
        <Select
            defaultValue={hasAll ? '' : 'hot'}
            value={value}
            onChange={onChange}
            style={{
                width: '100%',
            }}
        >
            {
                hasAll && <Option key='default' value=''>全部</Option>
            }
            {
                cates.map(item => (
                    <Option key={item._id} value={item.cate}>{item.cate_zh}</Option>
                ))
            }
        </Select>
    )
}