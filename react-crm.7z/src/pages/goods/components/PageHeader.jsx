
import { ArrowLeftOutlined } from "@ant-design/icons";
import './PageHeader.css';

export default (props) => {


    return (
        <div className="page_header" onClick={props.onBack}>
            <div className="left_icon">
                <ArrowLeftOutlined />
            </div>
            <div className="title">{props.title}</div>
        </div>
    )
}