export default {
    // 侧边菜单
    "menu.dashboard": "Dashboard",
    "menu.goods": "Goods Manage",
    "menu.goods.list": "Goods List",
    "menu.goods.add": "Goods Add",
    "menu.goods.edit": "Goods Edit",
    "menu.user": "User Manage",
    // 标题
    "dashboard.title": 'Dashboard',
    "goods.list.title": 'Goods List',
    "goods.form.title": 'Goods Add/Edit',
    "user.title": 'user manage',
    // 抽屉
    "setting.drawer.title": 'Setting',
}