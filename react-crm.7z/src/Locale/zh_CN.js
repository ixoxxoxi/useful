export default {
    // 侧边菜单
    "menu.dashboard": "首页大屏",
    "menu.goods": "商品管理",
    "menu.goods.list": "商品列表",
    "menu.goods.add": "商品添加",
    "menu.goods.edit": "商品编辑",
    "menu.user": "用户管理",
    // 标题
    "dashboard.title": '首页大屏',
    "goods.list.title": '商品列表',
    "goods.form.title": '商品添加/编辑',
    "user.title": '用户管理',
    // 抽屉
    "setting.drawer.title": '设置',
}