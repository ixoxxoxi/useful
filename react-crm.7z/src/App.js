import { HashRouter as Router, Route, Routes, Navigate } from 'react-router-dom';

// import Layout from './components/Layout';
// import Login from './pages/login';

// import Dashboard from './pages/dashboard'
// import User from './pages/user'
// import GoodsForm from './pages/goods/goodsForm';
// import GoodsList from './pages/goods/goodsList';

import RouterDOM from './router';
import { Provider } from 'react-redux';
import store from './store/index';


const App = () => (

  // <Router>
  //   {/* 结合Outlet组件效果与下面一样 */}
  //    <Routes>
  //     <Route path='/' element={<Layout />}>
  //       <Route path='/dashboard' element={<Dashboard />}></Route>
  //       <Route path='/User' element={<User />}></Route>
  //     </Route>
  //   </Routes>
  // </Router >
  // ---------------------
  // <Router>
  //   <Routes>
  //     <Route path="/*" element={
  //       <Layout>
  //         <Routes>
  //           <Route path='/dashboard' element={<Dashboard />}></Route>
  //           <Route path='/goods' element={<Navigate to='/goods/list' />}></Route>
  //           <Route path='/goods/list' element={<GoodsList />}></Route>
  //           <Route path='/goods/add' element={<GoodsForm />}></Route>
  //           <Route path='/goods/edit' element={<GoodsForm />}></Route>
  //           <Route path='/user' element={<User />}></Route>
  //         </Routes>
  //       </Layout>
  //     } />
  //     <Route path='/' element={<Navigate to='/dashboard' />} />
  //   </Routes>
  // </Router >

  <Provider store={store}>
    <Router>
      <RouterDOM />
    </Router>
  </Provider>

);
export default App;