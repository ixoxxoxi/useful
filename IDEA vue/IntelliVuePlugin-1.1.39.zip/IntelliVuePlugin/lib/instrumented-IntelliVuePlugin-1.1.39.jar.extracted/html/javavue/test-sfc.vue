<!--suppress UnterminatedStatementJS -->
<template>
  <div>
    <p>
      This is a test Vue <strong>Single File Component</strong>.
    </p>
    <p>
      <button @click="onClick">Click Me</button>
    </p>
  </div>
</template>

<script>
  console.log('The Vue SFC was loaded.')
  module.exports = {
    name: 'TestSFC',
    methods: {
      onClick() {
        alert('You clicked me.')
      }
    },
  }
</script>

<style>
  p {
    color: red;
  }
</style>
