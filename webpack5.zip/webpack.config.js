const { merge } = require('webpack-merge');

const base = require('./config/base.js');
const dev = require('./config/dev.js');
const build = require('./config/build.js');

module.exports = function (env) {
  const { development } = env;
  return development ? merge(base, dev) : merge(base, build);
};
