import $ from 'jquery';
import other from '../public/assets/js/other.js'
import '../public/assets/css/index.css';
import '../public/assets/css/reset.css';

console.log($);

$('body').css('background', 'lightblue');
$('body').text('Hello World!');

other()
