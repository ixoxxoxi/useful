const { HotModuleReplacementPlugin } = require('webpack');

module.exports = {
  mode: 'development',
  // devtool: 'eval-source-map',
  devServer: {
    hot: true,
    port: 3000,
    open: false,
  },
  plugins: [new HotModuleReplacementPlugin()],
};
