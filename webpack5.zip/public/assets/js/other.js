export default function() {
    console.log('other.js')
}