export default {
  namespaced: true,
  state: {
    data: {},
  },
  getters: {},
  mutations: {
    setData(state, data) {
      state.data = data;
    },
  },
  actions: {},
};
