import { createStore } from 'vuex';
import xx from './module/xx';
export default createStore({
  state: {},
  getters: {},
  mutations: {},
  actions: {},
  modules: { xx },
});
