export function fetchData() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve({ a: 1 });
    }, 3000);
  });
}
