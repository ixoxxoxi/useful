import { computed } from 'vue';
import store from '../store';

export const data = computed(() => {
  return store.state.xx.data;
});

export function setData(data) {
  store.commit('xx/setData', data);
}
