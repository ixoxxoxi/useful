<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" @click="getVal">
    <HelloWorld msg="Welcome to Your Vue.js App" />
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import { fetchData } from '@/api/index.js';
import { data, setData } from '@/utils/index.js';

export default {
  name: 'HomeView',
  components: {
    HelloWorld
  },
  beforeRouteEnter(to, from, next) {
    fetchData().then((res) => {
      setData(res)
      next();
    });
  },
  methods: {
    getVal() {
      console.log(data.value.a);
    }
  }
}
</script>
