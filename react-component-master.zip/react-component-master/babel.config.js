module.exports = {
    presets: [
        // 写成数组形式，可以传参
        ['@babel/preset-env', {}],
        ["@babel/preset-react", {}]
    ],
    plugins: [
        ["@babel/plugin-proposal-decorators", { "version": "legacy" }],
        "@babel/plugin-proposal-class-properties"
    ]
}