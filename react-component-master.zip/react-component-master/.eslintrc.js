module.exports = {
    // 对es6+新特性做更好的代码检测
    parser: '@babel/eslint-parser',
    "parserOptions": {
        "ecmaVersion": 6,
        "sourceType": "module",
        "ecmaFeatures": {
            "jsx": true
        }
    },
    // 集成airbnb对React代码校验
    extends: ['airbnb', 'airbnb/hooks'],
    "rules": {
        "semi": "error"
    }
}