const { merge } = require('webpack-merge')

const config = require('./config/config.js')
const build = require('./config/build.js')
const serve = require('./config/serve.js')

module.exports = function ({ development }) {
    return merge(config, development ? serve : build)
}