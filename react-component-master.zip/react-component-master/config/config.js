// 生产/开发公共配置

const path = require("path");
const HtmlWebpackPlugin = require('html-webpack-plugin');
// ProgressPlugin是webpack内置插件
const { ProgressPlugin, ProvidePlugin } = require('webpack');

module.exports = {
    entry: {
        // 把第三方包从业务代码中抽离出来
        chunk: ['react', 'react-dom/client'],
        app: {
            import: path.resolve(__dirname, '../', "src/main.js"),
            dependOn: 'chunk'
        }
    },
    output: {
        path: path.resolve(__dirname, '../', 'dist'),
        filename: 'js/[name].[chunkhash:8].js',
        clean: true,// 每次打包时删除之前打包的文件
    },
    // 配置插件
    plugins: [
        new HtmlWebpackPlugin({
            // template: './public/index.html'
            // 使用绝对路径
            template: path.resolve(__dirname, '../', 'public/index.html'),
            // 设置将script标签插入到body结束标签前
            inject: 'body',
            // 指定打包后页面的文件名
            filename: 'index.html',
            // 指定页面title标题
            // 需要在html文件另外设置一下
            // <%=htmlWebpackPlugin.options.title%>
            title: 'hello React'
        }),
        new ProgressPlugin({
            // handler(percentage, message, ...args) {
            //     if (percentage == 1) {
            //         console.log('打包/启动完成~');
            //     } else {
            //         console.log(`${Math.floor(percentage * 100)}%`);
            //     }
            // }
        }),
        new ProvidePlugin({
            React: path.resolve(__dirname, '../', 'node_modules/react/index.js')
        })
    ],
    module: {
        rules: [
            { test: /\.(js|jsx|ts|tsx)$/, use: 'babel-loader' },
            { test: /\.(css|scss)$/, use: ["style-loader", "css-loader", "sass-loader"] },
            // 图片处理  asset/resourse 相当于使用了file-loader
            { test: /\.(png|jpg|jpeg|svg|gif|webp)$/, type: 'asset/resource', generator: { filename: 'img/[name].[contenthash:8][ext]' } },
        ]
    },
    resolve: {
        // 配置src路径别名
        alias: {
            "@": path.resolve(__dirname, "../", "src")
        },
        // 允许省略哪些后缀
        extensions: ['.js', '.jsx', '.ts', '.tsx']
    }
}