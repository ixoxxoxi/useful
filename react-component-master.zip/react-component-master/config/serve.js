// 开发环境配置

const ESLintPlugin = require('eslint-webpack-plugin');

module.exports = {
    mode: 'development',
    devtool: "eval-source-map",
    // 配置本地开发服务器
    devServer: {
        port: 8080,
        // // 打包完成后自动打开浏览器
        // open:true，
        client: {
            overlay: {
                errors: true,
                // 警告提示不弹出模态框
                warnings: false
            }
        }
    },
    plugins: [
        new ESLintPlugin({
            eslintPath: 'eslint',
            extensions: ['js', 'jsx', 'ts', 'tsx'],
            exclude: ['node_modules'],// 不对node_modules中的代码进行校验
            fix: false,// 关闭自动修复功能
            formatter: 'stylelish'
        })
    ]
}
